import numpy as np
import matplotlib.pyplot as plt
import torch
import pandas as pd
import torch
from torch.utils.data import Dataset
from torchvision.transforms import ToTensor
import random
import math
from matplotlib.axes import Axes
from torch import nn
from torch.utils.data import DataLoader
from Models import ImageClassificationModel
import time
import torchvision
from torchvision import transforms

def train_loop(dataloader, model, loss_fn, optimizer):
    size = len(dataloader.dataset)
    model.train()
    for batch, (X, y) in enumerate(dataloader):
        pred = model(X)
        loss = loss_fn(pred, y)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        if batch % 2 == 0:
            loss, current = loss.item(), (batch + 1) * len(X)
            print(f"loss: {loss:>7f}  [{current:>5d}/{size:>5d}]")

def test_loop(dataloader, model, loss_fn):
    model.eval()
    size = len(dataloader.dataset)
    num_batches = len(dataloader)
    test_loss, correct = 0, 0
    with torch.no_grad():
        for X, y in dataloader:
            pred = model(X)
            test_loss += loss_fn(pred, y).item()
            for i in range(len(pred)):
                correct += (float(pred[i][0]) >= 0.5) == float(y[i])
    test_loss /= num_batches
    correct /= size
    print(f"Test Error: \n Accuracy: {(100*correct):>0.1f}%, Avg loss: {test_loss:>8f} \n")

classes = ('plane', 'car', 'bird', 'cat', 'deer', 'dog', 'frog', 'horse', 'ship', 'truck')

batchsize = 4
ImageSize = (224, 224)
learningRate = 0.1
epochs = 20

transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Lambda(lambda x: x if x.shape[0] == 3 else x.repeat(3, 1, 1)),
    transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
])

trainset = torchvision.datasets.CIFAR10(root='./data', train=True, download=True, transform=transform)
trainloader = torch.utils.data.DataLoader(trainset, batch_size=batchsize, shuffle=True)

testset = torchvision.datasets.CIFAR10(root='./data', train=False, download=True, transform=transform)
testloader = torch.utils.data.DataLoader(testset, batch_size=batchsize, shuffle=False)

classes = ('plane', 'car', 'bird', 'cat',
           'deer', 'dog', 'frog', 'horse', 'ship', 'truck')


testloader = DataLoader(testset, batchsize, True)
trainloader = DataLoader(trainset, batchsize, True)


model = ImageClassificationModel().to("cpu")

loss_fn = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=learningRate)

# for t in range(epochs):
#     print(f"Epoch {t+1}\n-------------------------------")
#     train_loop(trainloader, model, loss_fn, optimizer)
#     test_loop(testloader, model, loss_fn)
# print("Done!")


def imshow(img):
  ''' function to show image '''
  img = img / 2 + 0.5 # unnormalize
  npimg = img.numpy() # convert to numpy objects

  axes.set_data(np.transpose(npimg, (1, 2, 0)))
  fig.canvas.draw_idle()
  fig.canvas.start_event_loop(1e-3)

# get random training images with iter function
fig = plt.figure()
axes = plt.imshow(torch.zeros((200, 200, 3)))
fig.axes.append(axes)
plt.show(block=False)
lastupdate = time.time()
for image, label in testloader:
    if(time.time() - lastupdate > 0.1):
      # call function on our images
      imshow(torchvision.utils.make_grid(image))
      # print the class of the image
      print(label)
      lastupdate = time.time()

